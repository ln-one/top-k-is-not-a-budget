Compile main.tex using pdflatex/bibtex or latexmk. Tables are frozen from verified full-ranking v3 results; temporal evidence remains v2. Source package contains all required figures.
